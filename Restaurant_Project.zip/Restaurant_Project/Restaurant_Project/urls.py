"""
URL configuration for Restaurant_Project project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.contrib import admin
from django.urls import path,include
from django.conf import settings
from django.conf.urls.static import static
from Restro_App import views
from Restro_App.views import *
from django.contrib.auth import views as auth_views

from django.urls import path


urlpatterns = [
    path('admin/', admin.site.urls),  # Admin URL
    path('',HomeView,name='Home'),
    path('about',AboutView,name='About'),
    path('book_table',BookTableView,name='Book_Table'),
    path('menu',MenuView,name='Menu'),
    path('feedback/', views.FeedbackView, name='Feedback_Form'),




    path('search/', views.search_view, name='Search'),
    path('cart/', views.cart_view, name='Cart'),
    path('cart/add/<int:item_id>/', views.add_to_cart, name='Add_To_Cart'),
    path('cart/remove/<int:item_id>/', views.remove_from_cart, name='Remove_From_Cart'),

    path('login/', auth_views.LoginView.as_view(
        template_name='account.html',
        extra_context={'title': 'Login', 'button': 'Login'}), name='Login'),
    path('logout/', auth_views.LogoutView.as_view(), name='Logout'),
    path('register/', views.register, name='Register'),
]
if settings.DEBUG:
    urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)

