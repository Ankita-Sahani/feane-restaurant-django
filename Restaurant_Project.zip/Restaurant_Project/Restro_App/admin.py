from django.contrib import admin
from Restro_App.models import ItemList, Items, AboutUs, Feedback, BookTable

# Register your models here.


from django.contrib import admin
from Restro_App.models import ItemList, Items, AboutUs, Feedback, BookTable


class FeedbackAdmin(admin.ModelAdmin):
    list_display = ('User_name', 'Rate', 'Description')


class BookTableAdmin(admin.ModelAdmin):
    list_display = ('Name', 'Phone_number', 'Total_Person', 'Booking_date')


admin.site.register(ItemList)
admin.site.register(Items)
admin.site.register(AboutUs)
admin.site.register(Feedback, FeedbackAdmin)
admin.site.register(BookTable, BookTableAdmin)