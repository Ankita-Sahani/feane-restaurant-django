from django.contrib import messages
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render
from django.http import HttpResponse
from django.views import View
from streamlit import login
from django.contrib.auth.forms import UserCreationForm

from Restro_App.models import BookTable, Feedback, ItemList, Items

# Create your views here.
def HomeView(request):
    return render(request,'home.html')



def AboutView(request):
    return render(request, 'about.html')





def MenuView(request):
    items = Items.objects.select_related('Category')
    categories = ItemList.objects.all()
    return render(request, 'menu.html', {'items': items, 'categories': categories})
    



def BookTableView(request):
    if request.method == 'POST':
        try:
            BookTable.objects.create(
                Name=request.POST.get('name', '').strip()[:15],
                Phone_number=int(request.POST.get('phone', '')),
                Email=request.POST.get('email', '').strip(),
                Total_Person=int(request.POST.get('persons', 2)),
                Booking_date=request.POST.get('date'),
            )
            messages.success(request, 'Your table has been booked!')
        except (ValueError, TypeError):
            messages.error(request, 'Please check your details and try again.')
        return redirect('Book_Table')
    return render(request, 'book_table.html')


def search_view(request):
    q = request.GET.get('q', '').strip()
    results = Items.objects.none()
    if q:
        results = Items.objects.filter(
            Q(Item_name__icontains=q) | Q(description__icontains=q)
        ).select_related('Category')
    return render(request, 'search.html', {'q': q, 'results': results})


def add_to_cart(request, item_id):
    item = get_object_or_404(Items, id=item_id)
    cart = request.session.get('cart', {})
    key = str(item.id)
    cart[key] = cart.get(key, 0) + 1
    request.session['cart'] = cart
    messages.success(request, f'{item.Item_name} added to cart.')
    return redirect(request.META.get('HTTP_REFERER') or 'Menu')


def remove_from_cart(request, item_id):
    cart = request.session.get('cart', {})
    cart.pop(str(item_id), None)
    request.session['cart'] = cart
    return redirect('Cart')


def cart_view(request):
    cart = request.session.get('cart', {})
    rows, total = [], 0
    for item in Items.objects.filter(id__in=cart.keys()):
        qty = cart[str(item.id)]
        subtotal = item.price * qty
        total += subtotal
        rows.append({'item': item, 'qty': qty, 'subtotal': subtotal})
    return render(request, 'cart.html', {'rows': rows, 'total': total})


def register(request):
    form = UserCreationForm(request.POST or None)
    if request.method == 'POST' and form.is_valid():
        login(request, form.save())
        return redirect('Home')
    return render(request, 'account.html',
                  {'form': form, 'title': 'Sign Up', 'button': 'Create Account'})




def FeedbackView(request):
    if request.method == 'POST':
        name = request.POST.get('name', '').strip()[:15]
        message = request.POST.get('message', '').strip()
        try:
            rate = int(request.POST.get('rating', 5))
        except ValueError:
            rate = 5
        rate = max(1, min(5, rate))

        if name and message:
            Feedback.objects.create(User_name=name, Description=message, Rate=rate)
            messages.success(request, 'Thank you! Your feedback has been submitted.')
        else:
            messages.error(request, 'Please fill in all the fields.')
        return redirect('Feedback_Form')

    reviews = Feedback.objects.all().order_by('-id')[:10]
    return render(request, 'feedback.html', {'reviews': reviews})